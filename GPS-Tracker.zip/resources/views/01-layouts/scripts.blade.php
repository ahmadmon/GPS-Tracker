 <!-- latest jquery-->
 <script src="{{ asset('assets/js/jquery.min.js')}}"></script>
 <!-- Bootstrap js-->
 <script src="{{ asset('assets/js/bootstrap/popper.min.js')}}"></script>
 <script src="{{ asset('assets/js/bootstrap/bootstrap.bundle.min.js')}}"></script>
 <!-- feather icon js-->
 <script src="{{ asset('assets/js/icons/feather-icon/feather.min.js')}}"></script>
 <script src="{{ asset('assets/js/icons/feather-icon/feather-icon.js')}}"></script>
 <!-- scrollbar js-->
 <script src="{{ asset('assets/js/scrollbar/simplebar.js')}}"></script>
 <script src="{{ asset('assets/js/scrollbar/custom.js')}}"></script>
 <!-- Sidebar jquery-->
 <script src="{{ asset('assets/js/config.js')}}"></script>
 <!-- Plugins JS start-->
 <script src="{{ asset('assets/js/sidebar-menu.js')}}"></script>
 <script src="{{ asset('assets/js/slick/slick.min.js')}}"></script>
 <script src="{{ asset('assets/js/slick/slick.js')}}"></script>
 <script src="{{ asset('assets/js/header-slick.js')}}"></script>
 <script src="{{ asset('assets/js/prism/prism.min.js')}}"></script>
 <script src="{{ asset('assets/js/clipboard/clipboard.min.js')}}"></script>
 <script src="{{ asset('assets/js/custom-card/custom-card.js')}}"></script>
 <script src="{{ asset('assets/js/typeahead/handlebars.js')}}"></script>
 <script src="{{ asset('assets/js/typeahead/typeahead.bundle.js')}}"></script>
 <script src="{{ asset('assets/js/typeahead/typeahead.custom.js')}}"></script>
 <script src="{{ asset('assets/js/typeahead-search/handlebars.js')}}"></script>
 <script src="{{ asset('assets/js/typeahead-search/typeahead-custom.js')}}"></script>
 <script src="{{ asset('assets/js/sweet-alert/sweetalert.min.js')}}"></script>
 <x-livewire-alert::scripts />
 <!-- Plugins JS Ends-->
 <!-- Theme js-->
 <script src="{{ asset('assets/js/script.js')}}"></script>

