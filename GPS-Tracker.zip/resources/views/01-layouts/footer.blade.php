<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">تمام حقوق مادی و معنوی این سامانه متعلق به شرکت سمفا بوده و تمامی حقوق محفوظ است. ©
                    {{ jalaliDate(now(), format: 'Y') }}
                </p>
            </div>
        </div>
    </div>
</footer>
