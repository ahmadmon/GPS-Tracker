@extends('01-layouts.master')
@section('title', 'داشبورد')


@push('styles')

@endpush


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="alert alert-dark p-3 mt-4">
                <h5 class="text-center">به منظور بهبود عملکرد و ارائه خدمات بهتر، داشبورد شما در حال بازطراحی است. به زودی با امکانات جدید و کاربردی در خدمت شما خواهد بود.</h5>
            </div>
        </div>
    </div>
@endsection

@push('scripts')

@endpush
