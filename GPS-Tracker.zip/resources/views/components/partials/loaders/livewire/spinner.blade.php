<div wire:loading wire:target="{{ $target }}">
    <i class="fa-solid fa-circle-notch fa-spin"></i>
    <span>صبر کنید...</span>
</div>
