@extends('errors::minimal')

@section('title', "سامانه در دسترس نیست")
@section('code', '503')
@section('message', "سامانه در حال تعمیر و نگهداری است. به زودی مجدداً قابل دسترسی خواهد بود.")
