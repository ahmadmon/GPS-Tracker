@extends('errors::minimal')

@section('title', "خطای داخلی سرور")
@section('code', '500')
@section('message', "متاسفانه، در حال حاضر مشکلی در سرور سایت رخ داده است. لطفا بعداً مجدداً تلاش نمایید.")
