@extends('errors::minimal')

@section('title', 'صفحه یافت نشد')
@section('code', '404')
@section('message', 'متاسفانه، صفحه‌ای با این آدرس در سایت موجود نمی‌باشد.')
