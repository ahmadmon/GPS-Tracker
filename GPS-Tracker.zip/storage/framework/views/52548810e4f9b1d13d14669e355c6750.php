<?php use App\Enums\DeviceBrand; ?>


<?php $__env->startSection('title', 'تنظیمات دستگاه'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-12 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>">
                                <svg class="stroke-icon">
                                    <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#stroke-home')); ?>"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">
                            <a href="<?php echo e(route('device.index')); ?>">
                                دستگاه ها
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">تنظیمات دستگاه</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

        <!-- DEVICE INFO -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>اطلاعات دستگاه <?php echo e($device->name); ?></h5>
                <?php if(can('edit-device')): ?>
                <div>
                    <a href="<?php echo e(route('device.edit', $device->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="card-wrapper border row rounded-3">
                    <div class="col-12 mb-3">
                        <label class="form-label" for="name">نام

                        </label>
                        <input class="form-control" id="name" value="<?php echo e($device->name); ?>" type="text" disabled>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="model">مدل
                        </label>
                        <input class="form-control" id="model" value="<?php echo e($device->model); ?>" type="text" disabled>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="serial">شماره سریال (IMEI)
                        </label>
                        <input class="form-control" id="serial" value="<?php echo e($device->serial); ?>" disabled type="number">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="phone_number">شماره سیم‌کارت
                        </label>
                        <input class="form-control" dir="ltr" id="phone_number" value="<?php echo e($device->phone_number); ?>" disabled type="number">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="user_id">خریدار
                        </label>
                        <input class="form-control" id="user_id" value="<?php echo e($device->user->name); ?>" disabled type="text">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="password">رمز عبور</label>
                        <input class="form-control disabled" disabled id="password"
                               dir="<?php echo e($device->password ? 'ltr' : 'rtl'); ?>"
                               value="<?php echo e($device->password ?? 'رمز عبور پیشفرض'); ?>" type="text">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="brand">برند
                            <sup class="text-danger">*</sup>
                        </label>
                        <input class="form-control disabled" disabled id="brand" value="<?php echo e($device->brand); ?>"
                               type="text">
                    </div>
                </div>
            </div>
        </div>

    <!-- DEVICE CONNECTION -->
    <?php if (isset($component)) { $__componentOriginale6e556daaec85cc3855be3d831b95c6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6e556daaec85cc3855be3d831b95c6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alert.success-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alert.success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $attributes = $__attributesOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $component = $__componentOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__componentOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalede22ea52aea91b3b6e02b6278ea2476 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalede22ea52aea91b3b6e02b6278ea2476 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alert.error-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alert.error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalede22ea52aea91b3b6e02b6278ea2476)): ?>
<?php $attributes = $__attributesOriginalede22ea52aea91b3b6e02b6278ea2476; ?>
<?php unset($__attributesOriginalede22ea52aea91b3b6e02b6278ea2476); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalede22ea52aea91b3b6e02b6278ea2476)): ?>
<?php $component = $__componentOriginalede22ea52aea91b3b6e02b6278ea2476; ?>
<?php unset($__componentOriginalede22ea52aea91b3b6e02b6278ea2476); ?>
<?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>دستورات دستگاه</h5>
        </div>
        <div class="card-body">
            <div class="card-wrapper border rounded-3">
                <form action="<?php echo e(route('device.store-sms', $device->id)); ?>" method="POST" id="form">
                    <?php echo csrf_field(); ?>

                    <?php echo $__env->renderWhen($device->brand === DeviceBrand::SINOTRACK,'devices.partials.sinotrack-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                    <?php echo $__env->renderWhen($device->brand === DeviceBrand::CONCOX,'devices.partials.concox-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                    <?php echo $__env->renderWhen($device->brand === DeviceBrand::WANWAY,'devices.partials.wanway-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>


                    <div class="col-12 mt-2 text-end">
                        <button class="btn btn-primary" type="submit">ثــبــت</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('01-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/devices/device-setting.blade.php ENDPATH**/ ?>