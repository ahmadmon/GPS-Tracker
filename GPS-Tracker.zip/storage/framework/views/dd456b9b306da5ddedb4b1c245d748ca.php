<?php use Carbon\Carbon; ?>


<?php $__env->startSection('title', 'لیست حصارهای جغرافیایی'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/jquery.dataTables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-12 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>">
                                <svg class="stroke-icon">
                                    <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#stroke-home')); ?>"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">حصارهای جغرافیایی</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid">
        <?php if (isset($component)) { $__componentOriginale6e556daaec85cc3855be3d831b95c6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6e556daaec85cc3855be3d831b95c6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alert.success-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alert.success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $attributes = $__attributesOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $component = $__componentOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__componentOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
        <div class="row">
            <!-- Zero Configuration  Starts-->
            <div class="col-sm-12">
                <?php if(can('create-geofence')): ?>
                    <a href="<?php echo e(route('geofence.create')); ?>" class="btn btn-primary mb-4">+ ایجاد حصار جدید</a>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header pb-0 card-no-border">
                        <h4>لیست حصارهای جغرافیایی</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive custom-scrollbar text-nowrap">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>نام</th>
                                    <th>نوع</th>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['user'])): ?>
                                    <th>مختص به کاربر</th>
                                    <?php endif; ?>
                                    <th>مختص به دستگاه</th>
                                    <th>وضعیت</th>
                                    <th>زمان فعالیت حصار</th>
                                    <th>تاریخ ایجاد</th>
                                    <th>عملیات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $geofences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geofence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div>
                                                <?php if(can('edit-geofence')): ?>
                                                    <a class="f-14 mb-0 f-w-500 c-light"
                                                       href="<?php echo e(route('geofence.edit', $geofence->id)); ?>"><?php echo e($geofence->name); ?></a>
                                                <?php else: ?>
                                                    <span class="f-14 mb-0 f-w-500 c-light"><?php echo e($geofence->name); ?></span>
                                                <?php endif; ?>
                                                <p class="c-o-light text-muted"
                                                   data-bs-toggle="tooltip" data-bs-placement="top"
                                                   data-bs-title="<?php echo e($geofence?->description); ?>"
                                                ><?php echo e(str($geofence?->description)->limit(35)); ?></p>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($geofence->type): ?>
                                                <span class="badge dana rounded-pill badge-primary">ورود</span>
                                            <?php else: ?>
                                                <span class="badge dana rounded-pill badge-warning">خروج</span>
                                            <?php endif; ?>
                                        </td>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['user'])): ?>
                                        <td>
                                            <a href="<?php echo e(route('user.show', $geofence?->user->id)); ?>" target="_blank">
                                                <?php echo e($geofence?->user->name ?? '-'); ?>

                                            </a>
                                        </td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(route('device.show', $geofence->device->id)); ?>" target="_blank">
                                                <?php echo e($geofence->device->name); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php if (isset($component)) { $__componentOriginal4586163a4f84820dabfbe6187e157e8c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4586163a4f84820dabfbe6187e157e8c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alpine.change-status','data' => ['status' => (bool)$geofence->status,'url' => route('geofence.change-status',$geofence->id)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alpine.change-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((bool)$geofence->status),'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('geofence.change-status',$geofence->id))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4586163a4f84820dabfbe6187e157e8c)): ?>
<?php $attributes = $__attributesOriginal4586163a4f84820dabfbe6187e157e8c; ?>
<?php unset($__attributesOriginal4586163a4f84820dabfbe6187e157e8c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4586163a4f84820dabfbe6187e157e8c)): ?>
<?php $component = $__componentOriginal4586163a4f84820dabfbe6187e157e8c; ?>
<?php unset($__componentOriginal4586163a4f84820dabfbe6187e157e8c); ?>
<?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($geofence->start_time) && isset($geofence->end_time)): ?>
                                                از <?php echo e(Carbon::parse($geofence?->start_time)->format('H:i')); ?>

                                                الی <?php echo e(Carbon::parse($geofence?->end_time)->format('H:i')); ?>

                                            <?php else: ?>
                                                فاقد محدودیت زمانی
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="text-muted"><?php echo e(jalaliDate($geofence->created_at)); ?></span>
                                        </td>
                                        <td x-data="{ show: false }">
                                            <div class="btn-group" x-cloak x-show="!show">
                                                <button class="btn dropdown-toggle" type="button"
                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="icofont icofont-listing-box txt-dark"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-block text-center" style="">
                                                    <?php if(can('edit-geofence')): ?>

                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('geofence.edit', $geofence->id)); ?>">ویرایش</a>
                                                    <?php endif; ?>

                                                    <?php if(can('delete-geofence')): ?>
                                                        <a href="javascript:void(0)" class="dropdown-item"
                                                           @click.prevent="show = true">حذف</a>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                            <?php if (isset($component)) { $__componentOriginal6f9b8295202896f48787231add862b22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f9b8295202896f48787231add862b22 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.btns.confirm-rmv-btn','data' => ['url' => ''.e(route('geofence.destroy', $geofence->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.btns.confirm-rmv-btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('geofence.destroy', $geofence->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $attributes = $__attributesOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__attributesOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $component = $__componentOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__componentOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">داده ای یافت نشد.</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Zero Configuration  Ends-->
        </div>
    </div>

    <?php
        $sort = auth()->user()->hasRole(['user']) ? 5 : 6;
    ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/dataTables.bootstrap5.js')); ?>"></script>

    <script>
        $('#basic-1').DataTable({
            order: [[<?php echo e($sort); ?>, 'asc']],
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Persian.json"
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('01-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/admin/geofence/index.blade.php ENDPATH**/ ?>