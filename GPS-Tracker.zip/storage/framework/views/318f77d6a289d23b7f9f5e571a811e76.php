<!DOCTYPE html>
<html lang="fa_IR" dir="rtl">
<?php echo $__env->make('01-layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body dir="rtl">
    <!-- loader starts-->
    <div class="loader-wrapper">
        <div class="loader-index"> <span></span></div>
        <svg>
            <defs></defs>
            <filter id="goo">
                <fegaussianblur in="SourceGraphic" stddeviation="11" result="blur"></fegaussianblur>
                <fecolormatrix in="blur" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo">
                </fecolormatrix>
            </filter>
        </svg>
    </div>
    <!-- loader ends-->

    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->

    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">

        <!-- Page Header Start-->
        <?php echo $__env->make('01-layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page Header Ends -->


        <!-- Page Body Start-->
        <div class="page-body-wrapper horizontal-menu">

            <!-- Page Sidebar Start-->
            <?php echo $__env->make('01-layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page Sidebar Ends-->


            <div class="page-body">
                <div class="container-fluid pb-5">
                   <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

            <!-- footer start-->
            <?php echo $__env->make('01-layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- footer end-->

        </div>
    </div>



    <?php echo $__env->make('01-layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/01-layouts/master.blade.php ENDPATH**/ ?>