<div x-data="{ selected: '<?php echo e(old('command','')); ?>' }">
    <div class="mb-3">
        <label class="form-label" for="command">دستور مربوط به دستگاه را انتخاب کنید.
            <sup class="text-danger">*</sup>
        </label>
        <select class="form-control" id="command" name="command" x-model="selected">
            <option value="" selected>انتخاب کنید</option>
            <option value="0" <?php if(old('command') == 0): echo 'selected'; endif; ?>>فعالسازی دستگاه</option>
            <option value="1" <?php if(old('command') == 1): echo 'selected'; endif; ?>>تنظیم Apn خط</option>
            <option value="2" <?php if(old('command') == 2): echo 'selected'; endif; ?>>زمانبندی ارسال موقعیت</option>
            <option value="3" <?php if(old('command') == 3): echo 'selected'; endif; ?>>فعالسازی/ غیرفعالسازی رمزعبور</option>
            <option value="4" <?php if(old('command') == 4): echo 'selected'; endif; ?>>تنظیم رمز عبور</option>
            <option value="5" <?php if(old('command') == 5): echo 'selected'; endif; ?>>معرفی شماره ادمین</option>
            <option value="6" <?php if(old('command') == 6): echo 'selected'; endif; ?>>حذف شماره ادمین</option>
            <option value="7" <?php if(old('command') == 7): echo 'selected'; endif; ?>>بازگردانی دستگاه به حالت کارخانه
            </option>
        </select>
        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('command'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('command')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
    </div>

    <section class="row">
        <!-- APN -->
        <div class="mb-3" x-cloak x-show="parseInt(selected) === 1">
            <label class="form-label" for="selected-1">اپراتور سیم کارت داخل دستگاه را انتخاب کنید.
                <sup class="text-danger">*</sup>
            </label>
            <select class="form-select" name="apn" id="selected-1">
                <option value="mtnirancel" <?php if(old('apn') == 'mtnirancel'): echo 'selected'; endif; ?>>ایرانسل</option>
                <option value="mcinet" <?php if(old('apn') == 'mcinet'): echo 'selected'; endif; ?>>همراه اول</option>
                <option value="RighTel" <?php if(old('apn') == 'RighTel'): echo 'selected'; endif; ?>>رایتل</option>
                <option value="aptel" <?php if(old('apn') == 'aptel'): echo 'selected'; endif; ?>>آپتل</option>
            </select>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('apn'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('apn')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <!-- Upload Time Interval -->
        <div class="mb-3" x-cloak x-show="parseInt(selected) === 2">
            <label class="form-label" for="selected-2">زمان را بر حسب ثانیه وارد کنید
                <sup class="text-danger">*</sup>
            </label>
            <small class="text-muted d-block">در این بخش شما میتوانید مشخص کنید دستگاه در حالت حرکت
                چند ثانیه یکبارموقعیت را روی سامانه نشان دهد.</small>
            <strong class="text-muted d-block">حداقل زمان مجاز: 10</strong>
            <input class="form-control" id="selected-2" name="interval" type="number"
                   value="<?php echo e(old('interval')); ?>"
                   placeholder="برای مثال: 120">
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('interval'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('interval')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <!-- Active / deActive Device Password -->
        <div class="mb-3" x-cloak x-show="parseInt(selected) === 3">
            <div x-data="{ status: <?php echo \Illuminate\Support\Js::from(old('passStatus', boolval($device->password)))->toHtml() ?> }">
                <ul class="tg-list common-flex">
                    <?php if($device->password): ?>
                        <li>
                            <p class="fw-bold">
                                رمزعبور برای این دستگاه <span class="text-success">فعال</span> است , آیا میخواهید
                                غیرفعال کنید؟!
                            </p>
                        </li>
                    <?php else: ?>
                        <li>
                            <p class="fw-bold">
                                رمزعبور برای این دستگاه <span class="text-danger">غیرفعال</span> است , آیا میخواهید فعال
                                کنید؟!
                            </p>
                        </li>
                    <?php endif; ?>

                    <li class="tg-list-item">
                        <input class="tgl tgl-flip" id="cb5" type="checkbox" name="passStatus" x-model="status"
                               :checked="status">
                        <label class="tgl-btn" data-tg-off="غیرفعال" data-tg-on="فعال" for="cb5"></label>
                    </li>
                </ul>
                <div class="border border-dark rounded p-2">
                    <template x-if="status">
                        <small class="text-muted">
                            با فعال‌سازی رمز عبور، یک رمز عبور پیش‌فرض شش صفر (000000) برای دستگاه تنظیم خواهد شد.
                            <br>
                            از این پس برای انجام دستورات به دستگاه، وارد کردن این رمز عبور الزامی است.
                            <br>
                            برای تغییر رمز عبور پیش‌فرض، پس از فعال‌سازی، به بخش تنظیمات رمز عبور مراجعه فرمایید.
                        </small>
                    </template>
                    <template x-if="!status">
                        <small class="text-muted">با غیرفعال کردن رمز عبور دستگاه، رمز عبور فعلی حذف شده و برای انجام
                            دستورات پیامکی نیازی به وارد کردن رمز عبور نخواهد بود.</small>
                    </template>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('passStatus'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('passStatus')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <!-- Change Device Password -->
        <div class="mb-3" x-cloak x-show="parseInt(selected) === 4">
            <label class="form-label" for="selected-3">رمز عبور را وارد کنید
                <sup class="text-danger">*</sup>
            </label>
            <small class="text-muted d-block">رمز عبور باید شامل 6 عدد باشد</small>
            <small class="text-muted d-block">رمز عبور بپیشفرض برابر است با:
                <?php if($device->password): ?>
                    <strong class="text-danger">000000</strong>
                <?php else: ?>
                    <strong class="text-danger">رمز‌عبور ندارد.</strong>
                <?php endif; ?>
            </small>
            <div>
                <input class="form-control" x-model="password" id="selected-3" name="password" type="number"
                       value="<?php echo e(old('password')); ?>"
                       @input="if($el.value.length > 6) $el.value = $el.value.slice(0,6) ;"
                       placeholder="برای مثال: 123456">
                <p class="text-danger mt-2" x-show="error.length > 0" x-text="error"></p>
            </div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <!-- Set Admin Number -->
        <template x-if="parseInt(selected) === 5">
            <div class="mb-3">
                <label class="form-label" for="selected-4">شماره تماس ادمین
                    <sup class="text-danger">*</sup>
                </label>
                <small class="text-muted d-block">در این بخش، شماره ادمین را وارد کنید تا در صورت نیاز،
                    امکان دریافت اطلاعات از دستگاه فراهم شود.</small>
                <div class="row">
                    <div class="col-md-6">
                        <input class="form-control mb-3" id="selected-4" name="phones[0]" type="number"
                               value="<?php echo e(old('phones.0')); ?>"
                               placeholder="برای مثال: 09123456789">
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('phones.0'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phones.0')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control" id="selected-5" name="phones[1]" type="number"
                               value="<?php echo e(old('phones.1')); ?>"
                               placeholder="برای مثال: 09123456789">
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('phones.1'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phones.1')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                </div>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('phones'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phones')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
        </template>
        <!-- Delete Admin Number -->
        <template x-if="parseInt(selected) === 6">
            <div class="mb-3">
                <label class="form-label" for="selected-4">شماره تماس ادمین
                    <sup class="text-danger">*</sup>
                </label>
                <small class="text-muted d-block">در این بخش شما میتوانید شماره هایی را که به عنوان شماره های مدیر برای
                    دستگاه تعریف کرده اید را حذف کنید.</small>
                <input class="form-control" id="selected-4" name="phones[0]" type="number"
                       value="<?php echo e(old('phones.0')); ?>"
                       placeholder="برای مثال: 09123456789">
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('phones.0'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phones.0')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
        </template>
    </section>
</div>
<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/devices/partials/concox-settings.blade.php ENDPATH**/ ?>