<!DOCTYPE html>
<html lang="fa_IR" dir="rtl">
<head>
    <?php echo $__env->make('layouts.auth.head-tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body dir="rtl">
<!-- Auth page start-->

<div class="container-fluid p-0" >

    <?php echo $__env->yieldContent('content'); ?>

</div>

<?php echo $__env->make('layouts.auth.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/layouts/auth/auth.blade.php ENDPATH**/ ?>