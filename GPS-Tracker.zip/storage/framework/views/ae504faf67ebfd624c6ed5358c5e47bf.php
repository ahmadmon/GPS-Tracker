<?php $__env->startSection('title', 'صفحه یافت نشد'); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', 'متاسفانه، صفحه‌ای با این آدرس در سایت موجود نمی‌باشد.'); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/errors/404.blade.php ENDPATH**/ ?>