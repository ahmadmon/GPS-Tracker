<?php use App\Facades\Acl; ?>


<?php $__env->startSection('title', 'ثبت‌نام کاربر جدید'); ?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-12 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>">
                                <svg class="stroke-icon">
                                    <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#stroke-home')); ?>"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">
                            <a href="<?php echo e(route('user.index')); ?>">
                                لیست کاربران
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">ثبت‌نام کاربر جدید</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <form action="<?php echo e(route('user.store')); ?>" method="POST" class="row" autocomplete="off">
        <?php echo csrf_field(); ?>

        <!-- User Info -->
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['col-xl-4' => can('user-permissions'),
                      'col-12' => !can('user-permission')
                       ]); ?>">
            <div class="card">
                <h5 class="card-header">اطلاعات کاربر</h5>
                <div class="card-body">

                    <div class="col-12 mb-3">
                        <label class="form-label" for="name">نام و نام‌خانوادگی
                            <sup class="text-danger">*</sup>
                        </label>
                        <input class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" type="text">
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('name'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>


                    <div class="col-12 mb-3">
                        <label class="form-label" for="phone">شماره تماس
                            <sup class="text-danger">*</sup>
                        </label>
                        <input class="form-control" id="phone" dir="ltr" name="phone" value="<?php echo e(old('phone')); ?>"
                               type="text">
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('phone'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phone')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    <div class="col-12 mb-3">
                        <label class="form-label" for="password">رمز عبور</label>
                        <div class="input-group" x-data="{ show: false }">
                            <span class="input-group-text list-light-dark cursor-pointer" @click="show = !show"
                                  x-text="show ? 'مخفی' : 'نمایش'">نمایش</span>
                            <input class="form-control" dir="ltr" :type="show ? 'text' : 'password'"
                                   value="<?php echo e(old('password')); ?>" name="password" autocomplete="new-password"
                                   id="password">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>


                    <div x-data="{ selected: <?php echo \Illuminate\Support\Js::from(old('user_type', 0))->toHtml() ?> }">

                        <div class="col-12 mb-3">
                        <label class="form-label" for="user_type">نوع کاربر
                            <sup class="text-danger">*</sup>
                        </label>
                            <select class="form-select" name="user_type" id="user_type" x-model="selected">
                            <option value="0" selected <?php if(old('user_type') == 0): echo 'selected'; endif; ?>>کاربر</option>
                            <option value="1" <?php if(old('user_type') == 1): echo 'selected'; endif; ?>>ادمین</option>
                                <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['manager'])): ?>
                            <option value="2" <?php if(old('user_type') == 2): echo 'selected'; endif; ?>>سوپر ادمین</option>
                                <?php endif; ?>
                            <option value="3" <?php if(old('user_type') == 3): echo 'selected'; endif; ?>>مدیر سازمان</option>
                        </select>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('user_type'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('user_type')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            <?php if(can('user-permissions')): ?>
                                <div class="d-block">
                                    <small class="text-muted">لطفا نام کاربری و نقش را مشابه هم انتخاب کنید.</small>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-12 mb-3" x-cloak x-show="[0,1].includes(parseInt(selected))">
                        <label class="form-label" for="user_id">عضو سازمان
                            <sup class="text-danger">*</sup>
                        </label>
                            <?php
                                $options = $companies->mapWithKeys(fn($item) => [$item->id => implode(' - ', [$item->name , $item?->manager?->name])])->toArray();
                            ?>
                            <?php if (isset($component)) { $__componentOriginalbca81983a4fe5180c04eb7636ec35dff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbca81983a4fe5180c04eb7636ec35dff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alpine.input.select-option','data' => ['options' => $options,'name' => 'company_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alpine.input.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($options),'name' => 'company_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbca81983a4fe5180c04eb7636ec35dff)): ?>
<?php $attributes = $__attributesOriginalbca81983a4fe5180c04eb7636ec35dff; ?>
<?php unset($__attributesOriginalbca81983a4fe5180c04eb7636ec35dff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbca81983a4fe5180c04eb7636ec35dff)): ?>
<?php $component = $__componentOriginalbca81983a4fe5180c04eb7636ec35dff; ?>
<?php unset($__componentOriginalbca81983a4fe5180c04eb7636ec35dff); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('company_id'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('company_id')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                    </div>


                    <div class="col-12 mb-3">
                        <label class="form-label" for="status">وضعیت
                            <sup class="text-danger">*</sup>
                        </label>
                        <select class="form-select" name="status" id="status">
                            <option value="0" <?php if(old('status') == 0): echo 'selected'; endif; ?>>غیر فعال</option>
                            <option value="1" selected <?php if(old('status') == 1): echo 'selected'; endif; ?>>فعال</option>
                        </select>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('status'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('status')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                    <div class="col-12 mt-2">
                        <button class="btn btn-primary" type="submit">ایــــجاد</button>
                    </div>
                </div>
            </div>
        </div>
        <?php if(can('user-permissions')): ?>

            <!-- User Permissions -->
            <div class="col-xl-8">
                <div class="card">
                    <h5 class="card-header">نقش و مجوزها</h5>
                    <div class="card-body">
                        <div class="card-wrapper border rounded-3 h-100 checkbox-checked mb-4">
                            <div class="sub-title dana d-flex align-items-center justify-content-start">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24">
                                    <path fill="#1d1b1b"
                                          d="M15 21h-2a2 2 0 0 1 0-4h2v-2h-2a4 4 0 0 0 0 8h2Zm8-2a4 4 0 0 1-4 4h-2v-2h2a2 2 0 0 0 0-4h-2v-2h2a4 4 0 0 1 4 4"/>
                                    <path fill="#1d1b1b"
                                          d="M14 18h4v2h-4zm-7 1a6 6 0 0 1 .09-1H3v-1.4c0-2 4-3.1 6-3.1a8.6 8.6 0 0 1 1.35.125A5.95 5.95 0 0 1 13 13h5V4a2.006 2.006 0 0 0-2-2h-4.18a2.988 2.988 0 0 0-5.64 0H2a2.006 2.006 0 0 0-2 2v14a2.006 2.006 0 0 0 2 2h5.09A6 6 0 0 1 7 19M9 2a1 1 0 1 1-1 1a1.003 1.003 0 0 1 1-1m0 4a3 3 0 1 1-3 3a2.996 2.996 0 0 1 3-3"/>
                                </svg>
                                <span class="ms-2">انتخاب نقش </span>
                            </div>
                            <div class="my-1">
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('role')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('role'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <?php
                                if(Acl::hasRole(['manager'])){
                                       $roles = $roles->reject(fn($role) => in_array($role->title,['developer', 'super-admin']));
                                }
                                    $defaultRoleId = $roles->first()->id;
                            ?>
                            <div class="d-flex align-items-center justify-content-between flex-wrap"
                                 x-data="{ role: <?php echo json_encode( (int)old('role', $defaultRoleId), 512) ?> }">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" id="role-<?php echo e($role->id); ?>"
                                               value="<?php echo e($role->id); ?>"
                                               :checked="parseInt(role) === <?php echo e((int)$role->id); ?>"
                                               @change="$dispatch('updated-role', { roleName: '<?php echo e($role->title); ?>' })"
                                               type="radio" name="role">
                                        <label class="form-check-label cursor-pointer" for="role-<?php echo e($role->id); ?>"
                                               data-bs-toggle="tooltip"
                                               data-bs-placement="top"
                                               data-bs-title="<?php echo e($role->description); ?>"
                                        ><?php echo e($role->persian_name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="card-wrapper border rounded-3 h-100 checkbox-checked">
                            <div class="sub-title dana d-flex align-items-center justify-content-start">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 48 48">
                                    <g fill="none" stroke="#1d1b1b" stroke-linecap="round" stroke-width="4">
                                        <path stroke-linejoin="round"
                                              d="M20 10H6a2 2 0 0 0-2 2v26a2 2 0 0 0 2 2h36a2 2 0 0 0 2-2v-2.5"/>
                                        <path d="M10 23h8m-8 8h24"/>
                                        <circle cx="34" cy="16" r="6" stroke-linejoin="round"/>
                                        <path stroke-linejoin="round"
                                              d="M44 28.419C42.047 24.602 38 22 34 22s-5.993 1.133-8.05 3"/>
                                    </g>
                                </svg>
                                <span class="ms-2">انتخاب دسترسی ها </span>
                            </div>

                            <div x-data="permissionsList" class="row">
                                <div class="col-12"
                                     @updated-role.window="handleDispatch($event.detail.roleName)">
                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('permissions')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('permissions'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('permissions.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('permissions.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                </div>
                                <div class="col-12 mb-3 d-flex justify-content-start">
                                    <button type="button"
                                            class="btn btn-sm btn-outline-primary d-flex align-items-center me-3"
                                            @click="selectAll()">
                                        <svg class="me-1" xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                             viewBox="0 0 24 24">
                                            <mask id="lineMdCheckAll0">
                                                <g fill="none" stroke="#fff" stroke-dasharray="24"
                                                   stroke-dashoffset="24"
                                                   stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                                                    <path d="M2 13.5l4 4l10.75 -10.75">
                                                        <animate fill="freeze" attributeName="stroke-dashoffset"
                                                                 dur="0.4s"
                                                                 values="24;0"/>
                                                    </path>
                                                    <path stroke="#000" stroke-width="6" d="M7.5 13.5l4 4l10.75 -10.75">
                                                        <animate fill="freeze" attributeName="stroke-dashoffset"
                                                                 begin="0.4s" dur="0.4s" values="24;0"/>
                                                    </path>
                                                    <path d="M7.5 13.5l4 4l10.75 -10.75">
                                                        <animate fill="freeze" attributeName="stroke-dashoffset"
                                                                 begin="0.4s" dur="0.4s" values="24;0"/>
                                                    </path>
                                                </g>
                                            </mask>
                                            <rect width="24" height="24" fill="#7366FF" mask="url(#lineMdCheckAll0)"/>
                                        </svg>
                                        <span>انتخاب همه</span>
                                    </button>

                                    <button type="button"
                                            class="btn btn-sm btn-outline-danger d-flex align-items-center"
                                            @click="deselectAll()">
                                        <svg class="me-1" xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                             viewBox="0 0 32 32">
                                            <path fill="#FB1506"
                                                  d="M16 3.667C9.19 3.667 3.667 9.187 3.667 16S9.19 28.333 16 28.333c6.812 0 12.333-5.52 12.333-12.333S22.813 3.667 16 3.667m0 3c1.85 0 3.572.548 5.024 1.48L8.147 21.024A9.26 9.26 0 0 1 6.667 16c0-5.146 4.187-9.333 9.333-9.333m0 18.666a9.27 9.27 0 0 1-5.024-1.48l12.876-12.877A9.26 9.26 0 0 1 25.332 16c0 5.146-4.186 9.333-9.332 9.333"/>
                                        </svg>
                                        <span>انتخاب هیچکدام</span>
                                    </button>
                                    <hr>
                                </div>


                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-check checkbox checkbox-solid-dark mb-0 learning-header">
                                            <input class="form-check-input cursor-pointer"
                                                   value="<?php echo e($group); ?>"
                                                   :checked="permissions.length > 0 && permissions.every(permission => selectedPermissions.includes(permission.id))"
                                                   @change="toggleGroup('<?php echo e($group); ?>')"
                                                   id="<?php echo e($group); ?>" type="checkbox">
                                            <label class="form-check-label"
                                                   for="<?php echo e($group); ?>"> <?php echo e($group); ?></label>
                                        </div>
                                        <div class="ms-3">
                                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="">
                                                    <input class="form-check-input cursor-pointer"
                                                           value="<?php echo e($item['id']); ?>"
                                                           name="permissions[]"
                                                           :checked="selectedPermissions.includes(<?php echo e((int)$item['id']); ?>)"
                                                           @change="togglePermission(<?php echo e((int)$item['id']); ?>)"
                                                           id="<?php echo e($item['id']); ?>" type="checkbox">
                                                    <label class="form-check-label text-muted cursor-pointer"
                                                           for="<?php echo e($item['id']); ?>"> <?php echo e($item['persian_name']); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener('alpine:init', () => {
            Alpine.data('permissionsList', () => ({
                permissions: <?php echo json_encode($permissions, 15, 512) ?>,
                selectedPermissions: <?php echo json_encode(old('permissions', []), 512) ?>,

                init() {
                    if (this.selectedPermissions.length === 0) {
                        this.handleDispatch('<?php echo e($roles->firstWhere('id', old('role', $defaultRoleId))->title ?? null); ?>')
                    }

                    if (this.selectedPermissions.length > 0) {
                        this.selectedPermissions = this.selectedPermissions.flat().map(item => parseInt(item));
                    }
                },

                selectAll() {
                    this.selectedPermissions = Object.values(this.permissions).flat().map(permission => permission.id)
                },

                deselectAll() {
                    this.selectedPermissions = [];
                },

                toggleGroup(group) {
                    const groupIds = this.permissions[group].map(permission => permission.id)
                    if (groupIds.every(id => this.selectedPermissions.includes(id))) {
                        this.selectedPermissions = this.selectedPermissions.filter(id => !groupIds.includes(id));
                    } else {
                        this.selectedPermissions = [...new Set([...this.selectedPermissions, ...groupIds])];
                    }
                },

                togglePermission(id) {
                    if (this.selectedPermissions.includes(id)) {
                        this.selectedPermissions = this.selectedPermissions.filter(permissionId => permissionId !== id);
                    } else {
                        this.selectedPermissions.push(id);
                    }
                },

                handleDispatch($roleName) {
                    switch ($roleName) {
                        case 'super-admin':
                            this.selectAll();
                            break;
                        case 'manager':
                            this.selectAll();
                            break;
                        case 'developer':
                            this.selectAll();
                            break;
                        case 'user':
                            this.selectedPermissions = [32, 33, 37, 38, 39, 40, 41, 42, 44, 57, 58, 59, 60, 61, 62];
                            break
                        case 'admin':
                            this.selectedPermissions = [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 57, 58, 59, 60, 61, 62, 63];
                            break;
                        default:
                            this.deselectAll();
                    }
                }

            }))
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('01-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/user/create.blade.php ENDPATH**/ ?>