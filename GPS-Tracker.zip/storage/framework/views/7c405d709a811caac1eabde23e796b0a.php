<div class="page-header mb-4">
    <div class="header-wrapper row m-0">














        <div class="header-logo-wrapper col-auto p-0">
            <div class="logo-wrapper"><a href="<?php echo e(route('home')); ?>"><img class="img-fluid" width="30"
                                                                         src="<?php echo e(asset('assets/images/logo/samfa-logo.png')); ?>"
                                                                         alt="سمفا - سامانه هوشمند ردیابی پلیس امنیت اقتصادیGPS"></a></div>
            <div class="toggle-sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i>
            </div>
        </div>
        <div class="left-header col-xxl-5 col-xl-6 col-lg-5 col-md-4 col-sm-3 p-0">
            <div class="notification-slider">
                <div class="d-flex h-100">
                    <h6 class="mb-0 f-w-400"><span class="f-light">سمفا - سامانه هوشمند ردیابی GPS</span></h6>
                </div>
            </div>
        </div>
        <div class="nav-right col-xxl-7 col-xl-6 col-md-7 col-8 pull-right right-header p-0 ms-auto">
            <ul class="nav-menus">
                































































                <li>
                    <div class="mode">
                        <svg>
                            <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#moon')); ?>"></use>
                        </svg>
                    </div>
                </li>


























                <li class="profile-nav onhover-dropdown pe-0 py-0">
                    <div class="media profile-media"><img class="b-r-10"
                                                          src="<?php echo e(asset('assets/images/avtar/user.png')); ?>"
                                                          alt="">
                        <div class="media-body"><span><?php echo e(auth()->user()?->name); ?></span>
                            <p class="mb-0"><?php echo e(auth()->user()->roles->first()?->persian_name); ?><i
                                    class="middle fa fa-angle-down"></i></p>
                        </div>
                    </div>
                    <ul class="profile-dropdown onhover-show-div">
                        <li><a href="<?php echo e(route('profile.index')); ?>"><i data-feather="user"></i><span>حساب </span></a>
                        </li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <a onclick="$(this).parent().submit()" type="button"><i
                                        data-feather="log-out"> </i><span>خروج از سامانه</span></a>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>



















    </div>
</div>

<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/01-layouts/header.blade.php ENDPATH**/ ?>