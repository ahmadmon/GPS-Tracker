<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('assets/images/logo/favicon.ico')); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/favicon.ico')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/bootstrap.css')); ?>">
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- Custom css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom-style.css')); ?>">
</head>
<body>
<!-- page-wrapper Start-->
<div class="page-wrapper compact-wrapper" id="pageWrapper">
    <!-- error-layout start-->
    <div class="error-wrapper">
        <div class="container"><img class="img-100" src="<?php echo e(asset('assets/images/other-images/sad.png')); ?>" alt="">
            <div class="error-heading">
                <h2 class="headline font-primary"><?php echo $__env->yieldContent('code'); ?></h2>
            </div>
            <div class="col-md-8 offset-md-2">
                <p class="sub-content"><?php echo $__env->yieldContent('message'); ?></p>
            </div>
            <div><a class="btn btn-primary-gradien btn-lg" href="<?php echo e(route('home')); ?>">بازگشت به داشبورد</a></div>
        </div>
    </div>
    <!-- error-layout end-->
</div>
</body>
</html>
<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/errors/minimal.blade.php ENDPATH**/ ?>