<?php $__env->startSection('title', 'جزئیات کاربر'); ?>


<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/jquery.dataTables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-12 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>">
                                <svg class="stroke-icon">
                                    <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#stroke-home')); ?>"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">
                            <a href="<?php echo e(route('user.index')); ?>">
                                لیست کاربران
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">جزئیات کاربر</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <!-- User Info -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="d-flex align-items-center">
                        <i data-feather="user" style="width: 20px; padding-bottom: 5px" class="me-1"></i>
                        <span>اطلاعات کاربر</span>
                    </h5>
                    <?php if(can('edit-user')): ?>
                        <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="card-wrapper border rounded-3">
                        <div class="col-12 mb-3">
                            <label class="form-label" for="name">نام و نام‌خانوادگی
                            </label>
                            <input class="form-control" id="name" value="<?php echo e($user->name); ?>" type="text" disabled>
                        </div>


                        <div class="col-12 mb-3">
                            <label class="form-label" for="phone">شماره تماس
                            </label>
                            <input class="form-control" id="phone" dir="ltr" value="<?php echo e($user->phone); ?>"
                                   type="text" disabled>
                        </div>


                        <div class="col-12 mb-3">
                            <label class="form-label" for="user_type">سازمان
                            </label>
                            <input class="form-control" id="user_type"
                                   value="<?php echo e(implode(' - ',$user->joinedCompanies()->pluck('name')->toArray())); ?>"
                                   type="text" disabled>
                        </div>

                        <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['manager'])): ?>
                        <div class="col-12 mb-3">
                            <label class="form-label" for="user_type">نوع کاربر
                            </label>
                            <input class="form-control" id="user_type"
                                   value="<?php echo e($user->type['name']); ?>"
                                   type="text" disabled>
                        </div>
                        <?php endif; ?>


                        <div class="col-12 mb-3">
                            <label class="form-label" for="status">وضعیت
                            </label>
                            <input class="form-control" id="status"
                                   value="<?php echo e($user->status ? 'فعال' : 'غیر فعال'); ?>"
                                   type="text" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <!-- User Devices -->
            <div class="card mb-4">
                <div class="card-header pb-0 card-no-border">
                    <h5 class="d-flex justify-content-between align-items-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <i data-feather="cpu" style="width: 20px; padding-bottom: 5px" class="me-1"></i>
                            <span>دستگاه های کاربر</span>
                        </div>
                        <?php if(can('create-device')): ?>
                            <a href="<?php echo e(route('device.create')); ?>" class="btn btn-sm btn-primary">+ ایجاد دستگاه
                                جدید</a>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table class="display" id="basic-1">
                            <thead>
                            <tr>
                                <th>نام</th>
                                <th>مدل</th>
                                <th>شماره سیم کارت</th>
                                <th>وضعیت</th>
                                <th>متصل شده در</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $user->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span class="fw-bold"><?php echo e($device->name); ?></span>
                                            <small class="text-muted"><?php echo e($device->serial); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo e($device->model); ?></td>
                                    <td><?php echo e($device?->phone_number); ?></td>
                                    <td>
                                        <?php if($device->status): ?>
                                            <span class="badge dana rounded-pill badge-success">فعال</span>
                                        <?php else: ?>
                                            <span class="badge dana rounded-pill badge-danger">غیرفعال</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(jalaliDate($device?->connected_at,time:true)); ?></td>
                                    <td x-data="{ show: false }">
                                        <div class="btn-group" x-cloak x-show="!show">
                                            <button class="btn dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="icofont icofont-listing-box txt-dark"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-block text-center" style="">
                                                <?php if(can('edit-device')): ?>
                                                    <a class="dropdown-item "
                                                       href="<?php echo e(route('device.edit', $device->id)); ?>">ویرایش</a>
                                                <?php endif; ?>
                                                <?php if(can('delete-device')): ?>
                                                    <a href="javascript:void(0)" class="dropdown-item"
                                                       @click.prevent="show = true">حذف</a>
                                                <?php endif; ?>
                                                <?php if(can('device-settings')): ?>

                                                    <a href="<?php echo e(route('device.device-setting', $device->id)); ?>"
                                                       class="dropdown-item">دستورات دستگاه</a>
                                                <?php endif; ?>
                                                
                                                

                                            </ul>
                                        </div>
                                        <?php if(can('delete-device')): ?>
                                            <?php if (isset($component)) { $__componentOriginal6f9b8295202896f48787231add862b22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f9b8295202896f48787231add862b22 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.btns.confirm-rmv-btn','data' => ['url' => ''.e(route('device.destroy', $device->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.btns.confirm-rmv-btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('device.destroy', $device->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $attributes = $__attributesOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__attributesOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $component = $__componentOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__componentOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">داده ای یافت نشد.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- User Vehicles -->
            <div class="card">
                <div class="card-header pb-0 card-no-border">
                    <h5 class="d-flex justify-content-between align-items-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <i data-feather="truck" style="width: 20px; padding-bottom: 5px" class="me-1"></i>
                            <span>وسایل نقلیه کاربر</span>
                        </div>
                        <?php if(can('create-vehicle')): ?>
                            <a href="<?php echo e(route('vehicle.create')); ?>" class="btn btn-sm btn-primary">+ ایجاد وسیله نقلیه
                                جدید</a>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive custom-scrollbar text-nowrap">
                        <table class="display" id="basic-2">
                            <thead>
                            <tr>
                                <th>وسیله نقلیه</th>
                                <th>پلاک</th>
                                <th>وضعیت</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $user->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span class="fw-bold"><?php echo e($vehicle->name); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo e($vehicle->license_plate); ?></td>
                                    <td>
                                        <?php if($vehicle->status): ?>
                                            <span class="badge dana rounded-pill badge-success">فعال</span>
                                        <?php else: ?>
                                            <span class="badge dana rounded-pill badge-danger">غیرفعال</span>
                                        <?php endif; ?>
                                    </td>
                                    <td x-data="{ show: false }">
                                        <div class="btn-group" x-cloak x-show="!show">
                                            <button class="btn dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="icofont icofont-listing-box txt-dark"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-block text-center" style="">
                                                <?php if(can('edit-vehicle')): ?>
                                                    <a class="dropdown-item "
                                                       href="<?php echo e(route('vehicle.edit', $vehicle->id)); ?>">ویرایش</a>
                                                <?php endif; ?>
                                                <?php if(can('delete-vehicle')): ?>
                                                    <a href="javascript:void(0)" class="dropdown-item"
                                                       @click.prevent="show = true">حذف</a>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                        <?php if(can('delete-vehicle')): ?>
                                            <?php if (isset($component)) { $__componentOriginal6f9b8295202896f48787231add862b22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f9b8295202896f48787231add862b22 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.btns.confirm-rmv-btn','data' => ['url' => ''.e(route('vehicle.destroy', $vehicle->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.btns.confirm-rmv-btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('vehicle.destroy', $vehicle->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $attributes = $__attributesOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__attributesOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $component = $__componentOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__componentOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center">داده ای یافت نشد.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/datatable.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/dataTables.bootstrap5.js')); ?>"></script>
    <script>
        $('#basic-1').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Persian.json"
            }
        });

        $('#basic-2').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Persian.json"
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('01-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/user/show.blade.php ENDPATH**/ ?>