<div class="select-box w-100" data-component="<?php echo e($name); ?>">
    <div class="options-container mw-100">
        <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="selection-option">
                <input class="radio" id="<?php echo e($key); ?>" value="<?php echo e($key); ?>" type="radio" <?php if(old($name, $value ?? '') == $key): echo 'checked'; endif; ?>)>
                <label class="mb-0" for="<?php echo e($key); ?>"><?php echo e($option); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div>
               موردی یافت نشد...
            </div>
        <?php endif; ?>

    </div>
    <div class="selected-box rounded mw-100" style="padding: 9px 24px"><?php echo e($options[old($name, $value ?? '')] ?? 'انتخاب کنید...'); ?></div>
    <div class="search-box">
        <input type="text" class="mw-100" placeholder="جستجو کردن..." aria-label="search">
    </div>
    <input type="hidden" value="<?php echo e(old($name, $value ?? '')); ?>" name="<?php echo e($name); ?>" id="finalValue">
</div>

<?php if (! $__env->hasRenderedOnce('a5e995d4-8254-4d43-a328-4e904ab87ebf')): $__env->markAsRenderedOnce('a5e995d4-8254-4d43-a328-4e904ab87ebf');
$__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/custom/searchable-select-option.js')); ?>"></script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/components/partials/alpine/input/select-option.blade.php ENDPATH**/ ?>