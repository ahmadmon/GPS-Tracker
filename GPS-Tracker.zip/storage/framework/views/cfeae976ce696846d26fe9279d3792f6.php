 <!-- latest jquery-->
 <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
 <!-- Bootstrap js-->
 <script src="<?php echo e(asset('assets/js/bootstrap/popper.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
 <!-- feather icon js-->
 <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather-icon.js')); ?>"></script>
 <!-- scrollbar js-->
 <script src="<?php echo e(asset('assets/js/scrollbar/simplebar.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/scrollbar/custom.js')); ?>"></script>
 <!-- Sidebar jquery-->
 <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
 <!-- Plugins JS start-->
 <script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/slick/slick.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/slick/slick.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/header-slick.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/prism/prism.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/clipboard/clipboard.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/custom-card/custom-card.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/typeahead/handlebars.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/typeahead/typeahead.bundle.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/typeahead/typeahead.custom.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/typeahead-search/handlebars.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/typeahead-search/typeahead-custom.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/sweet-alert/sweetalert.min.js')); ?>"></script>
 <?php if (isset($component)) { $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-alert::components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $attributes = $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $component = $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
 <!-- Plugins JS Ends-->
 <!-- Theme js-->
 <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

<?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/01-layouts/scripts.blade.php ENDPATH**/ ?>