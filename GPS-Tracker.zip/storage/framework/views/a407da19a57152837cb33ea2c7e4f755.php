<?php $__env->startSection('title', 'لیست سازمان‌ ها'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/jquery.dataTables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-12 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>">
                                <svg class="stroke-icon">
                                    <use href="<?php echo e(asset('assets/svg/icon-sprite.svg#stroke-home')); ?>"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item dana">سازمان ها</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid">
        <?php if (isset($component)) { $__componentOriginale6e556daaec85cc3855be3d831b95c6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6e556daaec85cc3855be3d831b95c6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alert.success-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alert.success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $attributes = $__attributesOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__attributesOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6e556daaec85cc3855be3d831b95c6a)): ?>
<?php $component = $__componentOriginale6e556daaec85cc3855be3d831b95c6a; ?>
<?php unset($__componentOriginale6e556daaec85cc3855be3d831b95c6a); ?>
<?php endif; ?>
        <div class="row">
            <!-- Zero Configuration  Starts-->
            <div class="col-sm-12">
                <?php if(can('create-company')): ?>
                    <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary mb-4">+ ایجاد سازمان جدید</a>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header pb-0 card-no-border">
                        <h4>لیست سازمان ها</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive custom-scrollbar text-nowrap">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>سازمان</th>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['manager'])): ?>
                                    <th>مدیر</th>
                                    <?php endif; ?>
                                    <th>شماره تماس</th>
                                    <th>وضعیت</th>
                                    <th>تاریخ ایجاد</th>
                                    <th>عملیات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="currency-icon warning">
                                                    <img class="img-fluid" width="32" height="32"
                                                         src="<?php echo e($company->logo ?? asset('assets/images/custom/workplace-64px.png')); ?>"
                                                         alt="">
                                                </div>
                                                <div><a class="f-14 mb-0 f-w-500 c-light"
                                                        href="<?php echo e(route('company.show', $company->id)); ?>"><?php echo e($company->name); ?></a>
                                                    <p class="c-o-light text-muted cursor-pointer"
                                                       data-bs-toggle="tooltip" data-bs-placement="top"
                                                       data-bs-title="<?php echo e($company?->address); ?>"><?php echo e(str($company?->address)->limit(35)); ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('notRole', ['manager'])): ?>
                                        <td>
                                            <a href="<?php echo e(route('user.show', $company->manager->id)); ?>" target="_blank">
                                                <?php echo e($company->manager->name); ?>

                                            </a>
                                        </td>
                                        <?php endif; ?>
                                        <td><?php echo e($company->contact_number); ?></td>
                                        <td>
                                            <?php if (isset($component)) { $__componentOriginal4586163a4f84820dabfbe6187e157e8c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4586163a4f84820dabfbe6187e157e8c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.alpine.change-status','data' => ['status' => (bool)$company->status,'url' => route('company.change-status',$company->id)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.alpine.change-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((bool)$company->status),'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('company.change-status',$company->id))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4586163a4f84820dabfbe6187e157e8c)): ?>
<?php $attributes = $__attributesOriginal4586163a4f84820dabfbe6187e157e8c; ?>
<?php unset($__attributesOriginal4586163a4f84820dabfbe6187e157e8c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4586163a4f84820dabfbe6187e157e8c)): ?>
<?php $component = $__componentOriginal4586163a4f84820dabfbe6187e157e8c; ?>
<?php unset($__componentOriginal4586163a4f84820dabfbe6187e157e8c); ?>
<?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="text-muted"><?php echo e(jalaliDate($company->created_at)); ?></span>
                                        </td>
                                        <td x-data="{ show: false }">
                                            <div class="btn-group" x-cloak x-show="!show">
                                                <button class="btn dropdown-toggle" type="button"
                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="icofont icofont-listing-box txt-dark"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-block text-center" style="">
                                                    <?php if(can('edit-company')): ?>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('company.edit', $company->id)); ?>">ویرایش</a>
                                                    <?php endif; ?>
                                                    <?php if(can('delete-company')): ?>
                                                        <a href="javascript:void(0)" class="dropdown-item"
                                                           @click.prevent="show = true">حذف</a>
                                                    <?php endif; ?>
                                                    <?php if(can('show-company')): ?>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('company.show', $company->id)); ?>">مشاهده
                                                            جزئیات</a>
                                                    <?php endif; ?>
                                                    <?php if(can('manage-subsets')): ?>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('company.manage-subsets', $company->id)); ?>">مدیریت
                                                            زیرمجموعه ها</a>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                            <?php if (isset($component)) { $__componentOriginal6f9b8295202896f48787231add862b22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f9b8295202896f48787231add862b22 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.btns.confirm-rmv-btn','data' => ['url' => ''.e(route('company.destroy', $company->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.btns.confirm-rmv-btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('company.destroy', $company->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $attributes = $__attributesOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__attributesOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f9b8295202896f48787231add862b22)): ?>
<?php $component = $__componentOriginal6f9b8295202896f48787231add862b22; ?>
<?php unset($__componentOriginal6f9b8295202896f48787231add862b22); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">داده ای یافت نشد.</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Zero Configuration  Ends-->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatables/dataTables.bootstrap5.js')); ?>"></script>

    <script>
        $('#basic-1').DataTable({
            order: [[4, 'asc']],
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Persian.json"
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('01-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projects\GPS-Tracker\resources\views/company/index.blade.php ENDPATH**/ ?>